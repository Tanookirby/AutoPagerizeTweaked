#AutoPagerizeTweaked
A customized version of the Autopagerize extension created by swdyh